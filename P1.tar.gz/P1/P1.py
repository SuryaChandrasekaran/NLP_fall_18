# -*- coding: utf-8 -*-
"""
Created on Sun Sep 30 21:15:33 2018

@author: Surya Chandrasekaran """    
''' =============================================================================
#references:
    
1. python documentation. 
    
2. stackoverflow.com.
    
3. greedy algorithm tutorials in youtube. 
    https://www.youtube.com/watch?v=HzeK7g8cD0Y
    https://www.youtube.com/watch?v=ARvQcqJ_-NY
============================================================================='''
import sys
doc=''
for line in sys.stdin:
	doc+=line

#this function takes a word as input and returns the word split by hyphens(-) according to syllables
def hyphen(z):
    z = (z.lower())
    char = z
    vowels = ['a', 'e', 'i', 'o', 'u', 'y']
    for i in range(len(z) - 2):
        if char[i] in vowels and char[i + 1] in vowels:
            char = char[0:i + 2] + '-' + char[i + 2:]
        elif char[i] in vowels and char[i + 1] not in vowels and char[i + 2] not in vowels:
            if char[i + 1:i + 3] in ['ch', 'ph', 'sh', 'th', 'wh', 'ng', 'gh']:
                char = char[0:i + 1] + '-' + char[i + 1:]
            else:
                char = char[0:i + 2] + '-' + char[i + 2:]
        elif char[i] in vowels and char[i + 1] not in vowels:
            if char[i + 1] == 'w':
                char = char[0:i + 2] + '-' + char[i + 2:]
            else:
                char = char[0:i + 1] + '-' + char[i + 1:]
        else:
            pass
    return char

def format_document(width, text):
    # this variable stores the final formatted output
    out = ''
    width = int(width)
    for each_paragraph in text:
        # removing all extra spaces from the text, converting to one space
        each_paragraph = ' '.join((each_paragraph.split()))
        space_available = width
#    operations for each word in a paragraph
        for z in each_paragraph.split():
            length = len(z)
#        if length is less than line width then append it to output string
            if length <= space_available:
                space_available -= length + 1
                out += z + ' '
# else check for hyphenation and adjusting according to remaining space
            else:
                sp = hyphen(z)
                sp = sp.split('-')                
                if len(sp[0]) + 1 <= space_available:
                    space_available -= len(sp[0]) + 1
                    out += sp[0] + '-'
                    out += '\n'
                    space_available = width
                    for k in sp[1:]:
                        space_available -= len(k) + 1
                        out += k
                        space_available -= 1
                    out +=' '
                else:
                    # adding hyphenated word in next line
                    out += '\n'
                    space_available = width
                    for k in sp[0:]:
                        space_available -= len(k) + 1
                        out += k
                        space_available -= 1
                    out +=' '
        out += "\n\n"

    return out


#split by paragraph
document = doc.split('\n\n')
#get line width
width = document[0].split('\n')[0]
#get all lines from input except first line and store it in paragraph_split
paragraph_split = []
temporary_var=''
for i in range(1,len(document[0].split('\n'))):
    temporary_var += document[0].split('\n')[i]
paragraph_split.append(temporary_var)    
paragraph_split += document[1:] 
temp = ''
for i in paragraph_split:
    temp+=i+' '
try:
#    checking for incorrect value exceptions
    if not(int(width)):
        raise ValueError
    elif not(temp):
        raise Exception    
    #this variable stores the final formatted output
    else:
        out = format_document(width, paragraph_split)
        print(out)
except ValueError:
    print('First line should be an integer denoting line width')        
except Exception as e:
    print('Enter a non-empty string following the first line')
   
