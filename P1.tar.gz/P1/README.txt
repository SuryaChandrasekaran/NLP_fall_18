

This program takes in line width and a non-empty text as input from sydin and justifies it according to the line width specifies.It outputs the formatted 
document to stdout.

The program runs automatically with Autotest as specified by Prof. Ming-Hwa-Wang.

Authors of the code

1. Surya Chandrasekaran



 