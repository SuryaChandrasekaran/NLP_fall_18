
#!/opt/python-3.4/linux/bin/python3

if __name__ == "__main__":
  print("Last/Family Name: Chandrasekaran")
  print("First/Given Name: Surya")
  print("Gender: Male")
  print("ID: 1443177") # your ID is the 5- or 6-digit number
  print("Day-time Phone: 408/831-8659")	# this is optional
  print("Day-time Fax: N/A")				# this is optional
  print("Night-time Phone: N/A")			# this is optional
  print("Night-time Fax: N/A")			# this is optional
  print("Email: s1chandrasekaran@scu.edu emailforsurya@gmail.com")
  print("Previous Degrees with major:")
  print("\t B.Tech in Information Technology, Anna University, Chennai, TN, India")
  x = input()
  print(x)



