# Good Read

NLP summarized article suggestion based on user interests

Project uses django for UI and DB requirements

Due to size of project and DB, We have hosted to project files on GitHub
Please use run.sh to run the project

run.sh Does following things
1. Clone the project from GitHub
2. Create Virtualenv
3. Start Virtualenv
4. install dependancies
5. Run the local server

# Please make sure virtualenv and git are installed
```bash
sudo apt-get install git
sudo apt-get install virtualenv

```


## Usage

To run the application

```bash
sh run.sh

```

Open http://localhost:8000/ in browser
Select topic keywords from dropdown
[If dropdown is inactive, Please refresh the page and try again]


Included python files and notebook html for topic modelling and summarization for reference purpose

## Contributing
Pranayjeet Thakare

Surya Chandrasekaran

Vishal Bembalkar
