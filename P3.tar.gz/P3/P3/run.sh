
sudo apt-get install git
sudo apt-get install virtualenv

git clone https://github.com/JeetThakare/goodread.git

virtualenv -p python3 project4
cd goodread

pwd

source project4/bin/activate

pip install -r requirements.txt

python manage.py runserver
