# -*- coding: utf-8 -*-
"""
Created on Sun Oct 21 08:55:42 2018

@author: email
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Oct 10 20:35:35 2018

@author: email
"""

import sys
from nltk.stem import PorterStemmer
from nltk import word_tokenize

#generic tree with various functions
class Node(object):
    def __init__(self, data):
        self.data = data
        self.level=int(0)
        self.children=[]   
    
    def add_child(self, node):
        self.children.append(node)
        self.level+=1
    
    def getData(self):
        return str(self.data)
    
    def display_values(self):
        print(self.data)
        print([i.data for i in self.children])
        
    def remove_child(self,node):
        self.children.remove(node)
    

#creating node structures for all grammar rules
am=Node('am')
pm=Node('pm')
RB=Node('RB')
RB.add_child(am)
RB.add_child(pm)

one=Node(1)
two=Node(2)
three=Node(3)
four=Node(4)
five=Node(5)
six=Node(6)
seven=Node(7)
eight=Node(8)
nine=Node(9)
ten=Node(10)
eleven=Node(11)
twelve=Node(12)       
CD=Node('CD')    
CD.add_child(one)
CD.add_child(two)
CD.add_child(three)
CD.add_child(four)
CD.add_child(five)
CD.add_child(six)
CD.add_child(seven)
CD.add_child(eight)
CD.add_child(nine)
CD.add_child(ten)
CD.add_child(eleven)
CD.add_child(twelve)

Is=Node('is')
are=Node('are')
am=Node('am')
VBD=Node('VBD')
VBD.add_child(Is)
VBD.add_child(are)
VBD.add_child(am)


And=Node('and')
Or=Node('or')
but=Node('but')
Conj=Node('Conj')
Conj.add_child(And)
Conj.add_child(Or)
Conj.add_child(but)


In=Node('in')
on=Node('on')
at=Node('at')
From=Node('from')
to=Node('to')
near=Node('near')
Prep=Node('Prep')
Prep.add_child(In)
Prep.add_child(on)
Prep.add_child(at)
Prep.add_child(From)
Prep.add_child(near)


do=Node('do')
work=Node('work')
book=Node('book')
hold=Node('hold')
spend=Node('spend')
Open=Node('open')
call=Node('call')
have=Node('have')
eat=Node('eat')
Verb=Node('Verb')
Verb.add_child(do)
Verb.add_child(work)
Verb.add_child(book)
Verb.add_child(hold)
Verb.add_child(spend)
Verb.add_child(Open)
Verb.add_child(call)
Verb.add_child(have)
Verb.add_child(eat)



book=Node('book')
flight=Node('flight')
can=Node('can')
water=Node('water')
boy=Node('boy')
box=Node('box')
floor=Node('floor')
apple=Node('apple')
banana=Node('banana')
computer=Node('computer')
work=Node('work')
home=Node('home')
Noun=Node('Noun')
Noun.add_child(book)
Noun.add_child(flight)
Noun.add_child(can)
Noun.add_child(water)
Noun.add_child(boy)
Noun.add_child(box)
Noun.add_child(floor)
Noun.add_child(apple)
Noun.add_child(banana)
Noun.add_child(computer)
Noun.add_child(work)
Noun.add_child(home)



mary=Node('mary')
john=Node('john')
denver=Node('denver')
houston=Node('houston')
boston=Node('boston')
beijing=Node('beijing')
Proper_Noun=Node('Proper_Noun')
Proper_Noun.add_child(mary)
Proper_Noun.add_child(john)
Proper_Noun.add_child(denver)
Proper_Noun.add_child(houston)
Proper_Noun.add_child(boston)
Proper_Noun.add_child(beijing)


he=Node('he')
she=Node('she')
they=Node('they')
you=Node('you')
Pronoun=Node('Pronoun')
Pronoun.add_child(he)
Pronoun.add_child(she)
Pronoun.add_child(they)
Pronoun.add_child(you)

large=Node('large')
small=Node('small')
Adj=Node('Adj')
Adj.add_child(large)
Adj.add_child(small)

a=Node('a')
an=Node('an')
the=Node('the')
that=Node('that')
these=Node('these')
those=Node('those') 
Det=Node('Det')
Det.add_child(a)
Det.add_child(an)
Det.add_child(the)
Det.add_child(these)
Det.add_child(those)


can=Node('can')
may=Node('may')
will=Node('will')
do=Node('do')
Aux=Node('Aux')
Aux.add_child(can)
Aux.add_child(may)
Aux.add_child(will)
Aux.add_child(do)

NP=Node('NP')
VP=Node('VP')
PP=Node('PP')

S=Node('S')
S.add_child([NP,VP])
S.add_child([NP,VP,PP])
S.add_child([Aux,NP,VP])
S.add_child(VP)


Nominal=Node('Nominal')
Nominal.add_child(Noun)
Nominal.add_child(PP)
#Nominal.add_child(Prep)


NP.add_child(Pronoun)
NP.add_child(Proper_Noun)
NP.add_child([Det,Nominal])
NP.add_child([Det,Adj,Noun])
NP.add_child([Adj,Noun])
NP.add_child(Noun)
NP.add_child([CD,RB])
NP.add_child([PP])

PP.add_child(Prep)
#PP.add_child([Prep,NP])

VP.add_child(Verb)
VP.add_child([Verb,NP])
VP.add_child([Verb,NP,PP])
VP.add_child([Verb,PP])
VP.add_child([Aux,VP])
VP.add_child([VBD,VP])
VP.add_child(PP)
VP.add_child([Conj,VP])


lookahead_pointer=int(-1)


# checks if given word is present in the node or not
def Search(node,word_1):
    global lookahead_pointer
    global word

    ans=''
    if(node.getData()==word):
#    if it exceeds index then it is not there in the file
        ans=node.getData()  
        if(lookahead_pointer+1<len(tokens)):
            if(word in [',','.','?','!',';']):
#                word is a terminating character, so dont parse it in tree
                word=''
            else:
                lookahead_pointer+=1
                word=ps.stem(tokens[lookahead_pointer])
        elif(lookahead_pointer+1==len(tokens)):
            lookahead_pointer=0
            word=' '
            print('| | Noun')
            print('| | | '+ans)
            return '',''
        
        return True,ans
    else:
        return '',''

        
   #check on the next tree
   #unable to execute code as going to infinite loop after one full parsing
#            lookahead_pointer=-1
#            #remove s.children [0], searchand traverse again
#            S.remove_child(S.children[0])
#            word=ps.stem(tokens[lookahead_pointer])
#            searchAndTraverse(S,word)
#             return False,''


#checks if a word is present in a node that has no lists as any of its children                        
def searchInNonList(node,word_1):
    global word
    
    inNonList=False
    for i in node.children:
        try:
            inNonList,ans=Search(i,word)
        except AttributeError:
            pass
        if(inNonList):
           print('| | '+ node.getData())
           print('| | | '+ ans)
           

# checks if the word is present in a node that is a list or has a list in any of its children     
def searchInList(l,word_1):
    global word
   
    for i in l:
        if( i in [Aux,Det,Adj,Pronoun,Proper_Noun,Noun,Verb,Prep,Conj,VBD,CD,RB]):
            searchInNonList(i,word)
        else:
            print('| '+ i.getData())
            for j in i.children:
                if(isinstance(j,list)):
                        
                    searchInList(j,word)
                else:
                    searchInNonList(j,word)
            
             
# a function to search if the word exists in a node and then traverse the children of the node to check if the 
# word is present or not in any of them
def searchAndTraverse(node,word_1):
    global word
    x,y=Search(node,word)
    if(x==True):
        return node.getData()
    else:
        print('S')
        for i in node.children:
            if(isinstance(i,list)):
                searchInList(i,word)

            elif( i in [Aux,Det,Adj,Pronoun,Proper_Noun,Noun,Verb,Prep,Conj,VBD,CD,RB]):
                searchInNonList(i,word)
            
lines=''
for ll in sys.stdin:
    lines+=ll.rstrip()
#tokenize and stemmer  
ps = PorterStemmer()
lines=lines.split('\n')
    
try:
#    for multiple lines in a sentence, parse each of them
# this loop prints the word its datatype line number and its base form
    
    for i in range(len(lines)):
        tokens=word_tokenize(lines[i])
        for word in tokens:
            print(word+' ',end='')
            if(word in ['.','?','!'] ):
                if(i<len(lines)-2):
#                    end of sentence before last line
                    raise Exception('Sentence ends before last line. Invalid input')                    
                print('OP ',end='')
            elif(isinstance(word,str)):
                print('STRING ',end='')
            elif(isinstance(word,float)):
                print('FLOAT ',end='')
            elif(isinstance(word,int)):
                print('INT ',end='')
            else:
                print('OP', end='')  
            
            print(str(i+1)+' '+ ps.stem(word))

    print('ENDFILE')
# merge multi lines of a sentence into one line and parse for each word in them
    joined_line=''
    for i in range(len(lines)):
        joined_line+=lines[i]+' '
    
    tokens=word_tokenize(joined_line)
    lookahead_pointer+=1
    for i in range(0,len(S.children)):
        word=ps.stem(tokens[lookahead_pointer])
        try:
            searchAndTraverse(S,word)
        except:
            pass
#        remove each grammar rule as it is parsed for
        S.remove_child(S.children[0])

except Exception as e:
    print(e)
    
