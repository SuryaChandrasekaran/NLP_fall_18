# -*- coding: utf-8 -*-
"""
Created on Thu Oct 11 12:35:33 2018

@author: email
"""
from nltk.parse import RecursiveDescentParser
from nltk import CFG
import sys
from nltk.stem import PorterStemmer
from nltk import word_tokenize
 
lines= ''
for ll in sys.stdin:
	lines+=ll.rstrip()
#tokenize and stemmer 
ps = PorterStemmer()


lines=lines.split('\n')

try:
#    for multiple lines in a sentence, parse each of them
# this loop prints the word its datatype line number and its base form
    for i in range(len(lines)):           
        tokens=word_tokenize(lines[i])
        for word in tokens:
            print(word+' ',end='')
            if(word in [',','.','?','!'] ):
                if(i<len(lines)-2):
#               end of sentence before last line
                    raise Exception('Sentence ends before last line. Invalid input')
                print('OP ',end='')
            elif(isinstance(word,str)):
                print('STRING ',end='')
            elif(isinstance(word,float)):
                print('FLOAT ',end='')
            elif(isinstance(word,int)):
                print('INT ',end='')
            else:
                print('OP', end='')
            
            print(str(i+1)+' '+ ps.stem(word))
    print('ENDFILE')
    # merge multi lines of a sentence into one line and parse for each word in them
    joined_line=''
    for i in range(len(lines)):
        joined_line+=lines[i]+' '
#creating the rules for grammar that has to be followed
    grammar2 = CFG.fromstring("""
  S  -> NP VP | NP VP PP |Aux NP PP | VP
  NP -> Pronoun | ProperNoun | Det Nominal |Det Adj Noun | Adj Noun | Noun | CD RB | PP
  Nominal -> Noun | PP 
  VP -> Verb | Verb NP | Verb NP PP | Verb PP | Aux VP | VBD | PP | Conj 
  PP -> Prep NP  
  ProperNoun -> 'mary' | 'john' | 'houston' | 'denver' | 'boston' | 'beijing'
  Aux -> 'can' | 'may' | 'will' | 'do'
  Det -> 'the' | 'a'| 'an' | 'that' | 'these' | 'those'
  Noun -> 'boy' | 'box' | 'floor' | 'book' | 'flight' | 'can' | 'water' | 'apple' | 'banana' | 'computer' | 'work' | 'home'
  Adj  -> 'large' | 'small'
  Pronoun -> 'he' | 'she' | 'they' | 'you'   
  Verb ->  'open'  | 'do' | 'work' | 'book' | 'hold' | 'spend' | 'call' | 'have' | 'eat'
  Prep -> 'on' | 'in' | 'at' | 'from' | 'to' | 'near'
  Conj -> 'and' | 'or' | 'but'
  VBD -> 'is' | 'are' | 'am'
  RB -> 'am' | 'pm'
  CD -> '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | '11' | '12'  
  """)

    tokens=word_tokenize(joined_line)
#remove terminating punctuation from input
    for i in tokens:
        if(i in [',','.','?','!',';']):
            tokens.remove(i)
# stemming each word in sentence to its base form
    Stemmed_line=''
    for i in tokens:
        Stemmed_line+=ps.stem(i)+' '
# parsing the stemmed sentence to the grammar rules 
    tree=[]
    rd_parser = RecursiveDescentParser(grammar2)
    for t in rd_parser.parse(Stemmed_line.split()):
        tree.append(str(t))
    
    for i in range(len(tree)):
        tree[i]=tree[i].replace('  ','|')
        tree[i]=tree[i].replace(')','')
        tree[i]=tree[i].replace('(','')
        tree[i]=tree[i].replace(' ','\n||')
    
# print tree
    for i in tree:
        print(i)
#  prints exceptions  
except Exception as e:
    print(e)


