
This program implements recursive ascent and descent parser with backtracking and prints out all the possible parses for a sentence.
Only the grammar rules and the words list given by the professor for this assignment have been taken into consideration while parsing. 

The program runs automatically with Autotest as specified by Prof. Ming-Hwa-Wang.

Authors of the code
1. Surya Chandrasekaran

REFERENCES USED:
1. https://stackoverflow.com/questions/2482602/a-general-tree-implementation for designing a tree structure
2. http://www.nltk.org/howto/parse.html on how to parse using nltk libraries
3. https://www.nltk.org/book/ch08.html
4. https://link.springer.com/content/pdf/10.1007/3-540-53669-8_70.pdf for understanding the concepts behind recursive ascent/ descent parser.
5. https://www.youtube.com/watch?v=SH5F-rwWEog for undersing descent parser.

There are two implementations for the code, one is without using the RecursiveDescentParser module in nltk P2.py and one using it to parse the sentence P2_1.py.
Please rename P2_1 to P2 and move P2 to another directory if you want to Autotest the code that uses RecursiveDescentParser in nltk.




 
